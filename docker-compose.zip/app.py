import os
import requests
from flask import (
    Flask,
    get_flashed_messages,
    render_template,
    session,
    request,
    redirect,
    url_for,
    flash,
)

from src.text_utilities import TextUtilities


app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "supersecretkey")

utilities = TextUtilities()


@app.route("/", methods=["GET", "POST"])
def index():
    return utilities.format_time()


if __name__ == "__main__":
    app.run(debug=True)
